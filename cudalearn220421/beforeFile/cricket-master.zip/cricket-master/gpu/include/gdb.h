#ifndef _GDB_H_
#define _GDB_H_

int gdb_init (int argc, char **argv, char *execarg, char* pidarg);

#endif
