### 0.1.0

* support gpushare deployment

### 0.2.0

* fix not recover gpu exclusive scheduling after removing gpushare 

### 0.3.0

* support helm v3

### 0.4.0

* delete env kubeVersion

### 0.5.0

* change mount dir of host to /etc/kubernetes

### 0.6.0

* change statefulset to job

### 0.7.0

* Support unhealthy configmap
