from migration import prestop_signal

prestop_signal()